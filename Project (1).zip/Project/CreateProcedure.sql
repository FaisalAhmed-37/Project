
use ProjectDatabase;
go

create proc SP_InsertProjectDetails
									@PID as int,
									@ProjectManagerID as int,
									@EmployeeID as int,
									@DepartmentID as int,
									@HourlyRate as money
as
	begin
		begin try
			Insert into ProjectDetails(PID, ProjectManagerID, EmployeeID, DepartmentID, HourlyRate)
									   values (@PID,@ProjectManagerID,@EmployeeID,@DepartmentID,@HourlyRate);
		end try
		begin catch
			Select ERROR_MESSAGE() as ErrorMessage,
				   ERROR_SEVERITY() as Severity,
				   ERROR_LINE() as [LineNo];
		end catch
	end
go

create Function FN_GetBudget(@ProjectID  int)
returns money
as
begin
	declare @BudgetMoney  money;
	select @BudgetMoney = BudgetMoney from ProjectHeader as ph 
			where ph.PID = @ProjectID ;
	
	return @BudgetMoney;
end
go

create Function FN_EmployeeSalaryDetail(@EmployeeID as int)
returns table
as
	return
				select	e.EID as [EmployeeID] , 
						e.EName as [Employee Name], 
						ph.PTitle as [Project Title],
						d.DName as [Department Name],
						pd.HourlyRate, 
						e.EName as [Project Manager Name]
	from dbo.Employee as e 
	inner join dbo.ProjectDetails as pd
	on e.EID = pd.EmployeeID 
	inner join dbo.ProjectHeader as ph
	on pd.PID = ph.PID
	inner join dbo.Department as d
	on pd.DepartmentID = d.DID
	where e.EID = @EmployeeID
go 


Create trigger TR_ProjectHeader_UpdateInformation
on dbo.ProjectHeader
after update
as
begin
	declare @DeletedPID as int,
			@DeletedPTitle as int,
			@DeletedBudgetMoney as money;


	if UPDATE(BudgetMoney)	
	Insert into dbo.ProjectHeaderDataRecords (PID, PTitle, BudgetMoney)
					select d.PID, d.PTitle, d.BudgetMoney from deleted as d;

end
go